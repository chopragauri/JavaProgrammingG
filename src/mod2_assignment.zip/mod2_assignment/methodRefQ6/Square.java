package mod2_assignment.methodRefQ6;
@FunctionalInterface
public interface Square {
    double compute(int n);
}

