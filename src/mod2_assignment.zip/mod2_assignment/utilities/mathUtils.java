package mod2_assignment.utilities;
public class mathUtils {
    public int add(int a, int b) {
        return a + b;
    }
}

