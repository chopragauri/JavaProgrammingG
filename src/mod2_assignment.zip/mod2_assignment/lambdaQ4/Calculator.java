package mod2_assignment.lambdaQ4;
@FunctionalInterface
public interface Calculator {
    int compute(int a, int b);
}

