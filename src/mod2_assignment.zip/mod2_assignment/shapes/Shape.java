package mod2_assignment.shapes;

    public interface Shape {
        double area(double l, double b);
        double perimeter(double l, double b);
    }

